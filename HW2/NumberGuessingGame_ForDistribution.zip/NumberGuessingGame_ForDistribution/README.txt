⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆

Hello!

This is an algorithm where the computer guesses YOUR number. The computer will guess your number— if it is wrong, tell the computer whether your number is less than or greater than the number it guessed. You must be honest.

For running the program:
MACOSX–
To run this program, run the .command file by double-clicking it. It will then open a terminal with the game! ◕ ◡ ◕

WINDOWS–
To run this program, run the command "javac HW2_improved.java ANSI.java" in your terminal to compile the file. Then, in the same terminal, run the command "java HW2_improved" to run the program. ✿◕ ‿ ◕✿

⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆

Comment(s):
> I Initialized variables for possible user inputs(1,2, and 3), because it seems as though using integers by themselves ((userInput==1)) was not running correctly. All numerical inputs other than 1 were returning lower/higher numbers than the original guess.

> Having an if statement before the While loop was causing the program to send an extra user input line after telling the program that it had the correct number, so I removed that one and kept the same if statement inside of the While loop instead.

⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆⋆ ˚｡⋆୨୧˚　˚୨୧⋆｡˚ ⋆